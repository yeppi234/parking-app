import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  ScrollView,
  Animated,
  Modal,
  FlatList,
  TextInput,
  Alert,
  useWindowDimensions,
  StatusBar,
} from 'react-native';
import axios from 'axios';

// ============================================================
// 🔐 순수 자바스크립트 SHA-256 해싱 함수 (패키지 설치 불필요)
// ============================================================
function sha256(message) {
    function rightRotate(value, amount) {
        return (value >>> amount) | (value << (32 - amount));
    }

    const msgBytes = new TextEncoder().encode(message);
    const msgLen = msgBytes.length;
    const bitLen = msgLen * 8;

    const paddingLen = 64 - ((msgLen + 8) % 64);
    const totalLen = msgLen + paddingLen + 8;
    const bytes = new Uint8Array(totalLen);
    bytes.set(msgBytes, 0);
    bytes[msgLen] = 0x80;

    const view = new DataView(bytes.buffer);
    view.setUint32(totalLen - 4, bitLen, false);

    const K = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ];

    let h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a;
    let h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;

    for (let i = 0; i < bytes.length; i += 64) {
        const w = new Uint32Array(64);
        for (let j = 0; j < 16; j++) {
            w[j] = (bytes[i + j * 4] << 24) | (bytes[i + j * 4 + 1] << 16) |
                (bytes[i + j * 4 + 2] << 8) | bytes[i + j * 4 + 3];
        }
        for (let j = 16; j < 64; j++) {
            const s0 = rightRotate(w[j - 15], 7) ^ rightRotate(w[j - 15], 18) ^ (w[j - 15] >>> 3);
            const s1 = rightRotate(w[j - 2], 17) ^ rightRotate(w[j - 2], 19) ^ (w[j - 2] >>> 10);
            w[j] = (w[j - 16] + s0 + w[j - 7] + s1) | 0;
        }

        let a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;

        for (let j = 0; j < 64; j++) {
            const S1 = rightRotate(e, 6) ^ rightRotate(e, 11) ^ rightRotate(e, 25);
            const ch = (e & f) ^ (~e & g);
            const temp1 = (h + S1 + ch + K[j] + w[j]) | 0;
            const S0 = rightRotate(a, 2) ^ rightRotate(a, 13) ^ rightRotate(a, 22);
            const maj = (a & b) ^ (a & c) ^ (b & c);
            const temp2 = (S0 + maj) | 0;

            h = g;
            g = f;
            f = e;
            e = (d + temp1) | 0;
            d = c;
            c = b;
            b = a;
            a = (temp1 + temp2) | 0;
        }

        h0 = (h0 + a) | 0;
        h1 = (h1 + b) | 0;
        h2 = (h2 + c) | 0;
        h3 = (h3 + d) | 0;
        h4 = (h4 + e) | 0;
        h5 = (h5 + f) | 0;
        h6 = (h6 + g) | 0;
        h7 = (h7 + h) | 0;
    }

    function toHex(num) {
        return ('00000000' + (num >>> 0).toString(16)).slice(-8);
    }

    return toHex(h0) + toHex(h1) + toHex(h2) + toHex(h3) +
        toHex(h4) + toHex(h5) + toHex(h6) + toHex(h7);
}

// ============================================================
// 💾 메모리 스토리지 (AsyncStorage 대체 - 설치 불필요)
// ============================================================
let memoryStorage = {};

const storage = {
  setItem: (key, value) => {
    memoryStorage[key] = value;
    console.log(`💾 저장됨: ${key} = ${value}`);
    return Promise.resolve();
  },
  getItem: (key) => {
    const value = memoryStorage[key] || null;
    console.log(`📖 읽기: ${key} = ${value}`);
    return Promise.resolve(value);
  },
  removeItem: (key) => {
    delete memoryStorage[key];
    return Promise.resolve();
  },
};

// ============================================================
// API 기본 설정
// ============================================================
const API_URL = 'https://a17574.parkingweb.kr';
const LOGIN_URL = 'https://a17574.parkingweb.kr/login';

// ================== Axios 인스턴스 ==================
const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-Requested-With': 'XMLHttpRequest',
    'Accept': 'application/json, text/plain, */*',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
  },
  withCredentials: false,
});

// ============================================================
// 🔐 자동 로그인 함수 (SHA-256 적용)
// ============================================================
const performAutoLogin = async (id, pw) => {
  try {
    // 1. 비밀번호 SHA-256 해싱
    const hashedPw = sha256(pw);

    // 2. POST 데이터 구성
    const postData = `userId=${encodeURIComponent(id)}&userPwd=${hashedPw}`;

    // 3. Axios 요청
    const response = await axios.post(LOGIN_URL, postData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
        'Accept': 'application/json, text/plain, */*',
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': LOGIN_URL,
      },
      maxRedirects: 0,
      validateStatus: (status) => status >= 200 && status < 400,
      timeout: 10000,
    });

    // 4. 응답 헤더에서 JSESSIONID 추출
    const setCookie = response.headers['set-cookie'];
    if (setCookie) {
      const cookieString = Array.isArray(setCookie) ? setCookie.join('; ') : setCookie;
      const match = cookieString.match(/JSESSIONID=([^;]+)/);
      if (match && match[1]) {
        return { success: true, sessionId: match[1] };
      }
    }
    return { success: false, error: '로그인 응답에서 세션을 찾을 수 없습니다.' };
    
  } catch (error) {
    console.error('로그인 실패 상세:', error);

    if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
      return { success: false, error: '⏰ 요청 시간이 초과되었습니다. (10초)' };
    }

    if (error.response) {
      const status = error.response.status;
      let msg = error.response.data?.errorMsg || error.response.data?.message || '';
      return { success: false, error: `서버 오류 (${status}): ${msg}` };
    }

    return { success: false, error: `🌐 네트워크 오류: ${error.message}` };
  }
};

// ============================================================
// 메인 앱
// ============================================================
export default function App() {
const { width, height } = useWindowDimensions();
const isTablet = width >= 768;
const isLandscape = width > height;
const scale = Math.min(width / 375, 1.4);
const tabletScale = isTablet ? Math.min(scale, 1.3) : scale;

  // ===== 기존 상태 =====
  const [page, setPage] = useState('main');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [loading, setLoading] = useState(false);
  const [parkingData, setParkingData] = useState(null);
  const [error, setError] = useState(null);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastTitle, setToastTitle] = useState('주차 등록 완료');
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState('success');
  const fadeAnim = useState(new Animated.Value(0))[0];
  const [searchResults, setSearchResults] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);

  // ===== 🔐 인증 관련 상태 =====
  const [isAppReady, setIsAppReady] = useState(false);

  // ===== ⚙️ 설정 모달 상태 =====
  const [pinModalVisible, setPinModalVisible] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [passwordModalVisible, setPasswordModalVisible] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [isChanging, setIsChanging] = useState(false);

  const blinkAnim = useRef(new Animated.Value(0)).current;

  // ========== styles 정의 (early return 보다 위에!) ==========
  const styles = getStyles(width, height, scale, tabletScale, isTablet, isLandscape);

  // ============================================================
  // 🔐 앱 초기화
  // ============================================================
  useEffect(() => {
    const initApp = async () => {
      try {
        const storedId = await storage.getItem('login_id');
        const storedPw = await storage.getItem('login_pw');
        let id, pw;

        if (!storedId || !storedPw) {
          id = 'oasis_g';
          pw = 'wldnjs1234!';
          await storage.setItem('login_id', id);
          await storage.setItem('login_pw', pw);
        } else {
          id = storedId;
          pw = storedPw;
        }

        const result = await performAutoLogin(id, pw);
        if (result.success) {
          apiClient.defaults.headers.Cookie = `JSESSIONID=${result.sessionId}`;
          console.log('✅ 자동 로그인 성공');
        } else {
          console.warn('⚠️ 자동 로그인 실패:', result.error);
          setToastType('error');
          setToastTitle('⚠️ 로그인 실패');
          setToastMessage('설정에서 비밀번호를 확인해주세요.');
          setToastVisible(true);
        }
      } catch (error) {
        console.error('앱 초기화 오류:', error);
      } finally {
        setIsAppReady(true);
      }
    };
    initApp();
  }, []);

  // ============================================================
  // 🔄 인터셉터 (세션 만료 시 자동 재로그인)
  // ============================================================
  useEffect(() => {
    const interceptor = apiClient.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;
        if (
          (error.response?.status === 403 || error.response?.status === 401) &&
          !originalRequest._retry
        ) {
          originalRequest._retry = true;

          try {
            const id = await storage.getItem('login_id');
            const pw = await storage.getItem('login_pw');
            if (id && pw) {
              const result = await performAutoLogin(id, pw);
              if (result.success) {
                apiClient.defaults.headers.Cookie = `JSESSIONID=${result.sessionId}`;
                return apiClient(originalRequest);
              }
            }
          } catch (e) {
            console.error('재로그인 실패:', e);
          }
          
          setToastType('error');
          setToastTitle('⚠️ 로그인 필요');
          setToastMessage('설정에서 비밀번호를 갱신해주세요.');
          setToastVisible(true);
          return Promise.reject(error);
        }
        return Promise.reject(error);
      }
    );

    return () => {
      apiClient.interceptors.response.eject(interceptor);
    };
  }, []);

  // ========== 토스트 처리 ==========
  useEffect(() => {
    if (toastVisible) {
      Animated.sequence([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.delay(2500),
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start(() => {
        setToastVisible(false);
        if (toastTitle !== '⚠️ 안내') {
          setParkingData(null);
          setVehicleNumber('');
          setPage('main');
        }
      });
    }
  }, [toastVisible]);

useEffect(() => {
  if (parkingData) {
    blinkAnim.setValue(0); 
  }
}, [parkingData]);

  // 점멸 애니메이션
// 점멸 애니메이션
useEffect(() => {
  let animation = null;

  if (parkingData) {
    animation = Animated.loop(
      Animated.sequence([
        Animated.timing(blinkAnim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: false,
        }),
        Animated.timing(blinkAnim, {
          toValue: 0,
          duration: 500,
          useNativeDriver: false,
        }),
      ])
    );
    animation.start();
  }

  return () => {
    if (animation) {
      animation.stop();
    }
  };
}, [parkingData]);

  const backgroundColor = blinkAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['#FFEAA7', '#E35E3A'],
  });

  // ========== 시간 파싱 ==========
  const parseParkingTime = (timeStr) => {
    if (!timeStr) return { hours: 0, minutes: 0 };
    let hours = 0, minutes = 0, days = 0;

    if (timeStr.includes('일')) {
      const dayMatch = timeStr.match(/(\d+)일/);
      if (dayMatch) days = parseInt(dayMatch[1], 10);
    }
    if (timeStr.includes('시간')) {
      const hourMatch = timeStr.match(/(\d+)시간/);
      if (hourMatch) hours = parseInt(hourMatch[1], 10);
    }
    if (timeStr.includes('분')) {
      const minMatch = timeStr.match(/(\d+)분/);
      if (minMatch) minutes = parseInt(minMatch[1], 10);
    }
    if (timeStr.includes(':')) {
      const parts = timeStr.split(':');
      hours = parseInt(parts[0], 10) || 0;
      minutes = parseInt(parts[1], 10) || 0;
    }
    return { hours: hours + days * 24, minutes };
  };

  const calculateTotalParkingTime = (timeStr) => {
    const { hours, minutes } = parseParkingTime(timeStr);
    return hours * 60 + minutes;
  };

  const calculateFinalParkingTime = (timeStr) => {
    let totalMinutes = calculateTotalParkingTime(timeStr) + 30;
    return Math.min(totalMinutes, 600);
  };

  // ========== 할인 선택 ==========
  const selectDiscountType = (totalMinutes, discountList) => {
    if (!discountList || discountList.length === 0) return ['20'];
    const available = discountList.filter(d => d.id !== '14').sort((a, b) => a.discount_value - b.discount_value);
    const needComboTimes = [180, 300, 330, 390, 420, 540];
    if (!needComboTimes.includes(totalMinutes)) {
      for (const d of available) {
        if (d.discount_value >= totalMinutes) return [d.id];
      }
      return ['16'];
    }
    const combinable = available.filter(d => d.id === '20' || d.id === '21');
    const single = available.filter(d => d.id !== '20' && d.id !== '21');
    let bestCombo = null;
    let bestOver = Infinity;
    for (const d of available) {
      if (d.discount_value >= totalMinutes && d.discount_value < bestOver) {
        bestOver = d.discount_value;
        bestCombo = [d.id];
      }
    }
    const oneHour = combinable.find(d => d.id === '20');
    const twoHour = combinable.find(d => d.id === '21');
    if (oneHour) {
      for (const d of single) {
        const sum = oneHour.discount_value + d.discount_value;
        if (sum >= totalMinutes && sum - totalMinutes < bestOver) {
          bestOver = sum - totalMinutes;
          bestCombo = ['20', d.id];
        }
      }
    }
    if (twoHour) {
      for (const d of single) {
        const sum = twoHour.discount_value + d.discount_value;
        if (sum >= totalMinutes && sum - totalMinutes < bestOver) {
          bestOver = sum - totalMinutes;
          bestCombo = ['21', d.id];
        }
      }
    }
    if (oneHour && twoHour && oneHour.discount_value + twoHour.discount_value >= totalMinutes) {
      const over = oneHour.discount_value + twoHour.discount_value - totalMinutes;
      if (over < bestOver) {
        bestOver = over;
        bestCombo = ['20', '21'];
      }
    }
    return bestCombo || ['20'];
  };

  // ========== 키패드 ==========
  const handleNumberPress = (num) => {
    if (vehicleNumber.length < 10) {
      setVehicleNumber(vehicleNumber + num);
    }
  };
  const handleDeletePress = () => {
    setVehicleNumber(vehicleNumber.slice(0, -1));
  };

  // ========== 차량 검색 ==========
  const handleSearch = async () => {
    if (!apiClient.defaults.headers.Cookie) {
      setToastType('error');
      setToastTitle('⚠️ 로그인 필요');
      setToastMessage('설정에서 비밀번호를 확인해주세요.');
      setToastVisible(true);
      return;
    }
    if (vehicleNumber.length < 2) {
      setToastType('error');
      setToastTitle('⚠️ 안내');
      setToastMessage('차량 번호는 2자리 이상 입력해주세요');
      setToastVisible(true);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const today = new Date();
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const entryDate =
        yesterday.getFullYear() +
        String(yesterday.getMonth() + 1).padStart(2, '0') +
        String(yesterday.getDate()).padStart(2, '0');

      const listResponse = await apiClient.post('/discount/registration/listForDiscount', {
        iLotArea: '17574',
        entryDate,
        carNo: vehicleNumber,
      });
      const data = Array.isArray(listResponse.data) ? listResponse.data : [];
      if (data.length === 0) {
        setToastType('error');
        setToastTitle('⚠️ 안내');
        setToastMessage('검색 결과가 없습니다\n출차된 차량은 검색되지 않습니다');
        setToastVisible(true);
        setLoading(false);
        return;
      }
      if (data.length === 1) {
        await fetchDetailAndShowResult(data[0].id);
        return;
      }
      setSearchResults(data);
      setModalVisible(true);
      setLoading(false);
    } catch (err) {
      console.error(err);
      setError('조회 중 오류가 발생했습니다.');
      setToastType('error');
      setToastTitle('❌ 조회 실패');
      setToastMessage(err.message || '조회 중 오류가 발생했습니다.');
      setToastVisible(true);
      setLoading(false);
    }
  };

  // ========== 상세 정보 조회 ==========
  const fetchDetailAndShowResult = async (id) => {
    setLoading(true);
    try {
      const detailResponse = await apiClient.post('/discount/registration/getForDiscount', {
        id: id,
        member_id: 'oasis_g',
      });
      const detail = detailResponse.data;
      const discountList = detail.listDiscountType || [];
      const parkVisitCar = detail.parkVisitCar || [];
      const existingMinutes = parkVisitCar.reduce((sum, item) => sum + (parseFloat(item.dc_time) || 0), 0);
      const data = detail.parkEntry;
      const picturePath = data.acEntrancePicName || '';
      const pictureUrl = picturePath.startsWith('http') ? picturePath : `${API_URL}/image${picturePath}`;
      const { hours, minutes } = parseParkingTime(data.different_time);
      const displayDays = Math.floor(hours / 24);
      const displayHours = hours % 24;
      let formattedTime = '';
      if (displayDays > 0) formattedTime += `${displayDays}일 `;
      if (displayHours > 0) formattedTime += `${displayHours}시간 `;
      if (minutes > 0) formattedTime += `${minutes}분`;
      if (!formattedTime) formattedTime = '0분';

      setParkingData({
        id: data.iID,
        carNo: data.acPlate1,
        differentTime: formattedTime,
        originalTime: data.different_time,
        pictureUrl,
        discountList,
        existingMinutes,
        parkVisitCar,
      });
      setModalVisible(false);
      setSearchResults([]);
      setPage('result');
    } catch (err) {
      console.error(err);
      setToastType('error');
      setToastTitle('❌ 상세 조회 실패');
      setToastMessage(err.message || '상세 정보를 불러오지 못했습니다.');
      setToastVisible(true);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setPage('main');
    setParkingData(null);
    setVehicleNumber('');
    setError(null);
  };

  // ========== 등록 ==========
  const handleRegister = async () => {
    if (!parkingData) {
      setToastType('error');
      setToastTitle('⚠️ 안내');
      setToastMessage('먼저 차량을 조회해주세요.');
      setToastVisible(true);
      return;
    }
    const hasOasisRegistration = parkingData.parkVisitCar?.some((item) => {
      const account = item.account_no || '';
      const name = item.name || '';
      return account.includes('oasis') || name.includes('oasis');
    });
    if (hasOasisRegistration) {
      setToastType('error');
      setToastTitle('⚠️ 안내');
      setToastMessage('이미 등록된 차량입니다');
      setToastVisible(true);
      return;
    }
    const totalMinutesWithGrace = calculateFinalParkingTime(parkingData.originalTime);
    const roundedMinutes = Math.ceil(totalMinutesWithGrace / 30) * 30;
    const remainingMinutes = roundedMinutes - parkingData.existingMinutes;
    if (remainingMinutes <= 0) {
      setToastType('success');
      setToastTitle('주차 등록 완료');
      setToastMessage('30분 내로 출차 해주세요');
      setToastVisible(true);
      return;
    }
    setLoading(true);
    try {
      const discountIds = selectDiscountType(remainingMinutes, parkingData.discountList);
      if (!discountIds || discountIds.length === 0) {
        setToastType('error');
        setToastTitle('❌ 오류');
        setToastMessage('선택된 할인이 없습니다.');
        setToastVisible(true);
        setLoading(false);
        return;
      }
      for (const discountId of discountIds) {
        const response = await apiClient.post('/discount/registration/save', {
          peId: parkingData.id,
          carNo: vehicleNumber,
          discountType: discountId,
          saveCnt: '1',
          memo: '',
        });
        if (typeof response.data === 'string') {
          if (response.data.includes('<!DOCTYPE')) {
            setToastType('error');
            setToastTitle('⚠️ 세션 만료');
            setToastMessage('로그인 세션이 만료되었습니다');
            setToastVisible(true);
            return;
          }
          continue;
        }
        if (response.data === true || response.data === 'true' || (typeof response.data === 'object' && !response.data.errorMsg)) {
          continue;
        }
        setToastType('error');
        setToastTitle('❌ 등록 실패');
        setToastMessage(response.data?.errorMsg || '등록에 실패했습니다.');
        setToastVisible(true);
        return;
      }
      const originalTotalMinutes = calculateTotalParkingTime(parkingData.originalTime) + 30;
      const newTotalRegistered = parkingData.existingMinutes + remainingMinutes;
      const remainingAfterRegister = originalTotalMinutes - newTotalRegistered;
      if (originalTotalMinutes > 600) {
        const extraMinutes = originalTotalMinutes - 600;
        setToastType('error');
        setToastTitle('⚠️ 10시간 초과!');
        setToastMessage(`${extraMinutes}분 초과하여 추가요금이 발생합니다`);
      } else if (remainingAfterRegister <= 30 && remainingAfterRegister > 0) {
        setToastType('success');
        setToastTitle('주차 등록 완료');
        setToastMessage(`${remainingAfterRegister}분 내로 출차 해주세요`);
      } else {
        setToastType('success');
        setToastTitle('주차 등록 완료');
        setToastMessage('30분 내로 출차 해주세요');
      }
      setToastVisible(true);
    } catch (err) {
      setToastType('error');
      setToastTitle('❌ 오류 발생');
      setToastMessage(err.response?.data?.errorMsg || err.message || '알 수 없는 오류가 발생했습니다.');
      setToastVisible(true);
    } finally {
      setLoading(false);
    }
  };

  // ============================================================
  // 🔐 설정 관련 함수
  // ============================================================

  const handleSettingsPress = () => {
    setPinInput('');
    setPinModalVisible(true);
  };

  const handleConfirmPin = () => {
    if (pinInput === '0705') {
      setPinModalVisible(false);
      setPinInput('');
      setNewPassword('');
      setPasswordModalVisible(true);
    } else {
      Alert.alert('안내', '비밀번호가 올바르지 않습니다.');
      setPinInput('');
    }
  };

  const handleSaveNewPassword = async () => {
    if (!newPassword || newPassword.length < 4) {
      Alert.alert('알림', '비밀번호는 4자리 이상 입력해주세요.');
      return;
    }

    setIsChanging(true);

    try {
      const result = await performAutoLogin('oasis_g', newPassword);

      if (result.success) {
        await storage.setItem('login_id', 'oasis_g');
        await storage.setItem('login_pw', newPassword);
        apiClient.defaults.headers.Cookie = `JSESSIONID=${result.sessionId}`;
        
        setPasswordModalVisible(false);
        setToastType('success');
        setToastTitle('✅ 갱신 완료');
        setToastMessage('새 비밀번호로 자동 로그인됩니다.');
        setToastVisible(true);
      } else {
        Alert.alert(
          '인증 실패',
          `로그인에 실패했습니다.\n\n상세 오류: ${result.error}`
        );
      }
    } catch (error) {
      Alert.alert('오류', `알 수 없는 오류가 발생했습니다.\n${error.message}`);
    } finally {
      setIsChanging(false);
    }
  };

  // ============================================================
  // UI 렌더링
  // ============================================================

  if (!isAppReady) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#3498db" />
        <Text style={styles.loadingText}>앱 초기화 중...</Text>
      </View>
    );
  }

  const renderMainScreen = () => (
    <View style={styles.mainContainer}>
      <Text style={styles.title}>클럽디 오아시스 주차등록</Text>
      <Text style={styles.subtitle}>차량번호 4자리를 입력하세요</Text>

      <View style={styles.numberDisplay}>
        {Array.from({ length: 4 }, (_, i) => (
          <View key={i} style={styles.numberBox}>
            <Text style={styles.numberText}>{vehicleNumber[i] || ''}</Text>
          </View>
        ))}
      </View>

      <View style={styles.keypad}>
        {[
          ['1', '2', '3'],
          ['4', '5', '6'],
          ['7', '8', '9'],
          ['←', '0', '확인'],
        ].map((row, i) => (
          <View key={i} style={styles.keyRow}>
            {row.map((item) => {
              let btnStyle = styles.keyNumber;
              let textStyle = styles.keyText;
              if (item === '←') {
                btnStyle = styles.keyDelete;
                textStyle = [styles.keyText, styles.keyTextWhite];
              } else if (item === '확인') {
                btnStyle = styles.keyConfirm;
                textStyle = [styles.keyText, styles.keyTextWhite];
              }
              return (
                <TouchableOpacity
                  key={item}
                  style={[styles.keyButton, btnStyle]}
                  onPress={() => {
                    if (item === '←') handleDeletePress();
                    else if (item === '확인') handleSearch();
                    else handleNumberPress(item);
                  }}
                  disabled={loading}
                >
                  <Text style={textStyle}>{item}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        ))}
      </View>

      {error && <Text style={styles.errorText}>{error}</Text>}

      {loading && (
        <View style={styles.loadingOverlay}>
          <View style={styles.loadingBox}>
            <ActivityIndicator size="large" color="#3498db" />
            <Text style={styles.loadingText}>조회중...</Text>
          </View>
        </View>
      )}

      <TouchableOpacity
        style={[styles.floatingSettingsButton, isTablet && styles.floatingSettingsButtonTablet]}
        onPress={handleSettingsPress}
        activeOpacity={0.7}
      >
        <Text style={styles.settingsIcon}>⚙️</Text>
      </TouchableOpacity>
    </View>
  );

  const renderResultScreen = () => (
    <View style={styles.resultContainer}>
      <ScrollView contentContainerStyle={styles.resultContent}>
        {parkingData && (
          <>
            <View style={styles.card}>
              {parkingData.pictureUrl ? (
                <Image source={{ uri: parkingData.pictureUrl }} style={styles.image} />
              ) : (
                <View style={styles.noImage}><Text>사진 없음</Text></View>
              )}
              <View style={styles.infoBox}>
                <View style={styles.infoRow}>
                  <Text style={styles.label}>차량 번호</Text>
                  <Text style={styles.value}>{parkingData.carNo}</Text>
                </View>
                <View style={styles.infoRow}>
                  <Text style={styles.label}>주차 시간</Text>
                  <Text style={styles.value}>{parkingData.differentTime}</Text>
                </View>
              </View>
            </View>

            <Animated.View 
            key={parkingData?.id}
            style={[styles.noticeBox, { backgroundColor }]}>
              <Text style={styles.noticeText}>등록 시간부터 30분 이내 출차 시 무료</Text>
              <Text style={styles.noticeText}>30분 초과 시 10분당 800원</Text>
            </Animated.View>

            <View style={styles.buttonGroup}>
              <TouchableOpacity style={[styles.actionButton, styles.cancelButton]} onPress={handleCancel}>
                <Text style={styles.actionButtonText}>취소</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.actionButton, styles.registerButton]} onPress={handleRegister} disabled={loading}>
                <Text style={styles.actionButtonText}>등록</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
        {loading && (
          <View style={styles.loadingOverlay}>
            <View style={styles.loadingBox}>
              <ActivityIndicator size="large" color="#3498db" />
              <Text style={styles.loadingText}>등록중...</Text>
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );

 return (
  <View style={styles.container}>
    <StatusBar hidden={true} translucent={true} backgroundColor="transparent" />
    {page === 'main' ? renderMainScreen() : renderResultScreen()}
 
      {/* 차량 검색 결과 모달 */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>차량을 선택해주세요</Text>
            <FlatList
              data={searchResults}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.modalItem}
                  onPress={() => fetchDetailAndShowResult(item.id)}
                >
                  <Text style={styles.modalItemText}>{item.carNo}</Text>
                  <Text style={styles.modalItemSub}>입차시간: {item.entryDateToString}</Text>
                </TouchableOpacity>
              )}
              ItemSeparatorComponent={() => <View style={styles.modalSeparator} />}
            />
            <TouchableOpacity
              style={styles.modalCloseButton}
              onPress={() => {
                setModalVisible(false);
                setSearchResults([]);
              }}
            >
              <Text style={styles.modalCloseText}>취소</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* PIN 인증 모달 */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={pinModalVisible}
        onRequestClose={() => setPinModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContainer, isTablet && styles.modalContainerTablet]}>
            <Text style={styles.modalTitle}>🔐 관리자 인증{'\n'}</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="비밀번호를 입력하세요"
              placeholderTextColor="#999"
              secureTextEntry={true}
              keyboardType="numeric"
              value={pinInput}
              onChangeText={setPinInput}
              autoFocus={true}
              maxLength={10}
            />

            <View style={styles.modalButtonRow}>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalCancelButton]}
                onPress={() => {
                  setPinModalVisible(false);
                  setPinInput('');
                }}
              >
                <Text style={styles.modalButtonText}>취소</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalSaveButton]}
                onPress={handleConfirmPin}
              >
                <Text style={[styles.modalButtonText, { color: '#ffffff' }]}>확인</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* 비밀번호 변경 모달 */}
      <Modal
        animationType="fade"
        transparent={true}
        visible={passwordModalVisible}
        onRequestClose={() => setPasswordModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContainer, isTablet && styles.modalContainerTablet]}>
            <Text style={styles.modalTitle}>🔑 계정 비밀번호 변경</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="변경된 비밀번호를 입력하세요"
              placeholderTextColor="#999"
              secureTextEntry={true}
              value={newPassword}
              onChangeText={setNewPassword}
              autoFocus={true}
              editable={!isChanging}
            />

            <View style={styles.modalButtonRow}>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalCancelButton]}
                onPress={() => setPasswordModalVisible(false)}
                disabled={isChanging}
              >
                <Text style={styles.modalButtonText}>취소</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalSaveButton]}
                onPress={handleSaveNewPassword}
                disabled={isChanging}
              >
                {isChanging ? (
                  <ActivityIndicator size="small" color="#ffffff" />
                ) : (
                  <Text style={[styles.modalButtonText, { color: '#ffffff' }]}>저장</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* 토스트 */}
      {toastVisible && (
        <Animated.View style={[styles.toastContainer, { opacity: fadeAnim }]}>
          <View style={[styles.toastContent, toastType === 'error' && styles.toastContentError]}>
            <Text style={[styles.toastTitle, toastType === 'error' && styles.toastTitleError]}>
              {toastTitle}
            </Text>
            <Text style={[styles.toastMessage, toastType === 'error' && styles.toastMessageError]}>
              {toastMessage}
            </Text>
          </View>
        </Animated.View>
      )}
    </View>
  );
}

// ============================================================
// 스타일
// ============================================================
const getStyles = (width, height, scale, tabletScale, isTablet, isLandscape) => {
  const baseFont = isTablet ? 20 : 16;
  const bigFont = isTablet ? 30 : 24;
  const hugeFont = isTablet ? 36 : 28;
  const maxWidth = isTablet ? Math.min(width * 0.8, 600) : 400;

  return StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f5f6fa' },

    loadingContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#f5f6fa',
    },
    loadingBox: {
      backgroundColor: 'white',
      paddingHorizontal: 30 * tabletScale,
      paddingVertical: 25 * tabletScale,
      borderRadius: 15 * tabletScale,
      alignItems: 'center',
      shadowColor: '#000',
      shadowOpacity: 0.2,
      shadowRadius: 10,
      elevation: 10,
    },
    loadingText: {
      marginTop: 12,
      fontSize: 16,
      color: '#2c3e50',
    },

    mainContainer: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      padding: isLandscape ? 40 * tabletScale : 20 * tabletScale,
    },
    title: {
      fontSize: hugeFont,
      fontWeight: 'bold',
      color: '#2c3e50',
      marginBottom: 8 * tabletScale,
      textAlign: 'center',
    },
    subtitle: {
      fontSize: baseFont,
      color: '#7f8c8d',
      marginBottom: 30 * tabletScale,
      textAlign: 'center',
    },
    numberDisplay: {
      flexDirection: 'row',
      marginBottom: 30 * tabletScale,
      alignSelf: 'center',
    },
    numberBox: {
      width: 60 * tabletScale,
      height: 70 * tabletScale,
      borderWidth: 2,
      borderColor: '#3498db',
      borderRadius: 10 * tabletScale,
      marginHorizontal: 5 * tabletScale,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: 'white',
    },
    numberText: {
      fontSize: 30 * tabletScale,
      fontWeight: 'bold',
      color: '#2c3e50',
    },
    keypad: {
      width: '80%',
      maxWidth: 320 * tabletScale,
      alignSelf: 'center',
    },
    keyRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginBottom: 8 * tabletScale,
    },
    keyButton: {
      flex: 1,
      aspectRatio: 1.2,
      marginHorizontal: 4 * tabletScale,
      borderRadius: 10 * tabletScale,
      justifyContent: 'center',
      alignItems: 'center',
      shadowColor: '#000',
      shadowOpacity: 0.1,
      shadowRadius: 3,
      elevation: 2,
    },
    keyNumber: { backgroundColor: 'white' },
    keyDelete: { backgroundColor: '#e74c3c' },
    keyConfirm: { backgroundColor: '#3498db' },
    keyText: {
      fontSize: 24 * tabletScale,
      fontWeight: '500',
      color: '#2c3e50',
    },
    keyTextWhite: { color: 'white' },
    errorText: {
      color: 'red',
      fontSize: 14 * tabletScale,
      backgroundColor: '#fde0e0',
      padding: 10 * tabletScale,
      borderRadius: 8 * tabletScale,
      width: '100%',
      textAlign: 'center',
      marginTop: 10 * tabletScale,
    },
    loadingOverlay: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: 'rgba(255,255,255,0.5)',
      zIndex: 999,
    },

    resultContainer: { flex: 1, backgroundColor: '#f5f6fa' },
    resultContent: {
      padding: 12 * tabletScale,
      alignItems: 'center',
      flexGrow: 1,
      justifyContent: 'center',
    },
    card: {
      backgroundColor: 'white',
      width: '100%',
      maxWidth: maxWidth,
      borderRadius: 15 * tabletScale,
      padding: 14 * tabletScale,
      marginTop: 0,
      shadowColor: '#000',
      shadowOpacity: 0.08,
      shadowRadius: 8,
      elevation: 3,
      alignItems: 'center',
      alignSelf: 'center',
    },
    image: {
      width: '100%',
      height: 200 * tabletScale,
      borderRadius: 10 * tabletScale,
      marginBottom: 16 * tabletScale,
      resizeMode: 'cover',
    },
    noImage: {
      width: '100%',
      height: 200 * tabletScale,
      backgroundColor: '#ecf0f1',
      borderRadius: 10 * tabletScale,
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 16 * tabletScale,
    },
    infoBox: {
      width: '100%',
      paddingVertical: 4 * tabletScale,
    },
    infoRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: 4 * tabletScale,
      borderBottomWidth: 1,
      borderBottomColor: '#f0f0f0',
    },
    label: {
      fontSize: baseFont,
      color: '#7f8c8d',
      fontWeight: '500',
    },
    value: {
      fontSize: bigFont,
      fontWeight: '600',
      color: '#2c3e50',
    },
    noticeBox: {
      borderWidth: 2,
      borderColor: '#ffc107',
      borderRadius: 10 * tabletScale,
      paddingVertical: 8 * tabletScale,
      paddingHorizontal: 12 * tabletScale,
      marginTop: 4 * tabletScale,
      alignItems: 'center',
      width: '100%',
      maxWidth: maxWidth,
      alignSelf: 'center',
    },
    noticeText: {
      fontSize: isTablet ? 26 : 22,
      fontWeight: '700',
      color: '#000000',
      textAlign: 'center',
      lineHeight: isTablet ? 44 : 40,
    },
    buttonGroup: {
      flexDirection: 'row',
      width: '100%',
      maxWidth: maxWidth,
      justifyContent: 'space-between',
      marginTop: 6 * tabletScale,
      marginBottom: 0,
      alignSelf: 'center',
      gap: 8 * tabletScale,
    },
    actionButton: {
      flex: 1,
      paddingVertical: 20 * tabletScale,
      borderRadius: 10 * tabletScale,
      alignItems: 'center',
      justifyContent: 'center',
    },
    cancelButton: { backgroundColor: '#e74c3c' },
    registerButton: { backgroundColor: '#27ae60' },
    actionButtonText: {
      color: 'white',
      fontSize: isTablet ? 24 : 20,
      fontWeight: 'bold',
      textAlign: 'center',
    },

    floatingSettingsButton: {
      position: 'absolute',
      bottom: 10,
      right: 10,
      width: 40,
      height: 40,
      borderRadius: 28,
      backgroundColor: '',
      justifyContent: 'center',
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.3,
      shadowRadius: 4,
      elevation: 5,
      zIndex: 999,
    },
    floatingSettingsButtonTablet: {
      width: 40,
      height: 40,
      borderRadius: 36,
      bottom: 40,
      right: 40,
    },
    settingsIcon: {
      fontSize: isTablet ? 36 : 28,
      color: '#ffffff',
    },

    modalOverlay: {
      flex: 1,
      backgroundColor: 'rgba(0,0,0,0.5)',
      justifyContent: 'center',
      alignItems: 'center',
    },
    modalContainer: {
      backgroundColor: 'white',
      borderRadius: 16,
      padding: 24,
      width: '80%',
      maxWidth: 360,
      maxHeight: '70%',
      shadowColor: '#000',
      shadowOpacity: 0.25,
      shadowRadius: 10,
      elevation: 10,
    },
    modalContainerTablet: {
      maxWidth: 400,
      padding: 32,
    },
    modalTitle: {
      fontSize: isTablet ? 26 : 20,
      fontWeight: 'bold',
      color: '#2c3e50',
      textAlign: 'center',
      marginBottom: 8,
    },
    modalDescription: {
      fontSize: 16,
      color: '#7f8c8d',
      marginBottom: 20,
      textAlign: 'center',
      lineHeight: 24,
    },
    modalInput: {
      borderWidth: 1,
      borderColor: '#ddd',
      borderRadius: 8,
      paddingVertical: 12,
      paddingHorizontal: 16,
      fontSize: 18,
      marginBottom: 24,
      backgroundColor: '#f8f9fa',
    },
    modalButtonRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      gap: 12,
    },
    modalButton: {
      flex: 1,
      paddingVertical: 14,
      borderRadius: 8,
      alignItems: 'center',
      justifyContent: 'center',
    },
    modalCancelButton: {
      backgroundColor: '#ecf0f1',
    },
    modalSaveButton: {
      backgroundColor: '#3498db',
    },
    modalButtonText: {
      fontSize: 16,
      fontWeight: '600',
      color: '#2c3e50',
    },

    modalItem: {
      paddingVertical: 14,
      paddingHorizontal: 12,
    },
    modalItemText: {
      fontSize: 18,
      fontWeight: '600',
      color: '#2c3e50',
    },
    modalItemSub: {
      fontSize: 14,
      color: '#7f8c8d',
      marginTop: 2,
    },
    modalSeparator: {
      height: 1,
      backgroundColor: '#ecf0f1',
    },
    modalCloseButton: {
      marginTop: 16,
      paddingVertical: 12,
      borderRadius: 10,
      backgroundColor: '#e74c3c',
      alignItems: 'center',
    },
    modalCloseText: {
      color: 'white',
      fontSize: 16,
      fontWeight: 'bold',
    },

    toastContainer: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: 'rgba(0,0,0,0.4)',
    },
    toastContent: {
      backgroundColor: 'white',
      paddingHorizontal: 30 * tabletScale,
      paddingVertical: 25 * tabletScale,
      borderRadius: 15 * tabletScale,
      alignItems: 'center',
      shadowColor: '#000',
      shadowOpacity: 0.3,
      shadowRadius: 10,
      elevation: 10,
    },
    toastContentError: {
      backgroundColor: '#fff5f5',
      borderWidth: 2,
      borderColor: '#e74c3c',
    },
    toastTitle: {
      fontSize: isTablet ? 28 : 22,
      fontWeight: 'bold',
      color: '#27ae60',
      marginBottom: 8 * tabletScale,
      textAlign: 'center',
    },
    toastTitleError: { color: '#e74c3c' },
    toastMessage: {
      fontSize: isTablet ? 20 : 16,
      color: '#2c3e50',
      textAlign: 'center',
    },
    toastMessageError: {
      color: '#c0392b',
      fontSize: isTablet ? 22 : 18,
      fontWeight: '600',
    },
  });
};